package bus;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import net.htmlparser.jericho.Element;
import net.htmlparser.jericho.HTMLElementName;
import net.htmlparser.jericho.Source;

public class BusParser_toSchool {
	public URL Url; // URL 占쏙옙체
	public HttpURLConnection con; // 占쏙옙占쏙옙占쏙옙 占쏙옙占쏙옙 connection
	public InputStream ret; // 占쏙옙占쏙옙占쌔쇽옙 占쌀쏙옙 占쏙옙占쏙옙 占쏙옙체占쏙옙 占쏙옙占쏙옙占쏙옙 占쏙옙占쏙옙

	public BusParser_toSchool() {
	}

	public InputStream Crawler(String Address) {
		try {
			Url = new URL(Address);
		} catch (Exception e) {
			System.err.println(e);
		}

		if (Address == null || Address.length() == 0) {
			System.err.println("address setup->setUrl(String str)");
			return null;
		} else {
			try {
				con = (HttpURLConnection) Url.openConnection();
				con.setDoOutput(true); // 占쏙옙쩍占싣�占쏙옙 占쏙옙占� 占쏙옙占쏙옙占싹곤옙 占쏙옙
				ret = con.getInputStream();
			} catch (Exception e) {
				System.err.println(e);
				return null;
			}
		}
		return ret;
	}

	public List<Bus> Parserer(InputStream input)
			throws UnsupportedEncodingException {
		Source source = null;
		List<Bus> bus = new ArrayList<Bus>();
		TimeSplit ts = new TimeSplit();

		try {
			source = new Source(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
		source.fullSequentialParse(); // 占쏙옙占쌜븝옙占쏙옙 占쏙옙占쏙옙占쏙옙 占승그듸옙占쏙옙 parse

		List<Element> table = source.getAllElements(HTMLElementName.TABLE);
		Element form = null;
		String find = "";

		for (Element e : table) {
			find = e.getAttributeValue("cellpadding");
			if (find != null && find.equals("1")) {
				form = e;
				break;
			}
		}
		if (form == null)
			return null;

		List<Element> trs = form.getAllElements(HTMLElementName.TR);
		for (int i = 1; i < trs.size(); i++) {
			Bus b = new Bus();
			String six, hwan, school;

			// version check
			if (i == 1) {
				if (b.getVesion() == null) {
					b.setVersion("1511");
					b.setSiz(Integer.toString(trs.size()));
				} else if (!b.getSiz().equals(Integer.toString(trs.size()))) {
					int aa = Integer.parseInt(b.getVesion());
					aa = aa + 1;
					b.setVersion(Integer.toString(aa));
					b.setSiz(Integer.toString(trs.size()));
				}
				bus.add(b);
			}
			
			// �븰湲곗쨷留됱감
			else if ((i == trs.size() - 1)
					&& (trs.get(i).getChildElements().size() == 3)) {
			}

			// morning cars
			else if (trs.get(i).getChildElements().size() == 3) {
				six = trs.get(i).getChildElements().get(0).getContent()
						.toString();
				hwan = trs.get(i).getChildElements().get(1).getContent()
						.toString();
				school = trs.get(i).getChildElements().get(2).getContent()
						.toString();

				int a = hwan.indexOf(":");
				b.setTimeSplit(ts.ampm(hwan.substring(0, a)));

				school = ts.spt(school);
				hwan = ts.spt(hwan);
				six = ts.spt(six);

				if (six.contains("바로크"))
					b.setSix("바로크가구점");
				// if (six.contains(URLEncoder.encode("점", "utf-8")))
				// b.setSix(six.split(URLEncoder.encode("점", "utf-8"))[0]);
				else if (six.contains("두호"))
					b.setSix("두호주민센터");
				else if (six.contains("환호"))
					b.setSix("환호동");
				else
					b.setSix(six);
				b.setHwan(hwan);
				b.setSchool(school);

				a = hwan.indexOf(":");
				b.setTZone(hwan.substring(0, a));

				bus.add(b);
			}

			// �씪諛섏감�뱾
			else if ((trs.get(i).getChildElements().size() == 5)) {
				six = trs.get(i).getChildElements().get(2).getContent()
						.toString();
				hwan = trs.get(i).getChildElements().get(3).getContent()
						.toString();
				school = trs.get(i).getChildElements().get(4).getContent()
						.toString();

				int a = hwan.indexOf(":");
				b.setTimeSplit(ts.ampm(hwan.substring(0, a)));

				school = ts.spt(school);
				hwan = ts.spt(hwan);
				six = ts.spt(six);

				if ((school.contains("-")) && (hwan.contains("-"))
						&& (six.contains("-"))) {
				} else {
					b.setSix(six);
					b.setHwan(hwan);
					b.setSchool(school);
					if (six.contains(":")) {
						a = six.indexOf(":");
						b.setTZone(six.substring(0, a));
					} else if (hwan.contains(":")) {
						a = hwan.indexOf(":");
						b.setTZone(hwan.substring(0, a));
					}
					bus.add(b);
				}
			}

		}
		return bus;
	}
}